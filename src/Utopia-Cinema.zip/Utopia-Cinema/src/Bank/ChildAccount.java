package Bank;

public class ChildAccount extends Account {
    //set startbalance and fees
    public ChildAccount(int credit) {
        balance = credit;
        fee = 2;
    }
}
