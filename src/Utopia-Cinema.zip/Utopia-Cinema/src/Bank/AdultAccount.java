package Bank;


public class AdultAccount extends Account {
    //set startbalance and fees
    public AdultAccount(int credit) {
        balance = credit;
        fee = 10;
    }
}
