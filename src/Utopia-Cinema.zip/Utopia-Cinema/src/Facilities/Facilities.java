package Facilities;

import Citizen.Citizen;

import java.util.ArrayList;

public abstract class Facilities {
    void getBestService(Citizen citizen, ArrayList<String> attributes) {

    }
}
