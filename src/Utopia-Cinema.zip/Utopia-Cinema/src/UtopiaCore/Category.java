package UtopiaCore;

public enum Category {
    Sleep,
    Food,
    Money,
    Toilet,
    Health,
    Fun,
    Anger,
    Sad
}
