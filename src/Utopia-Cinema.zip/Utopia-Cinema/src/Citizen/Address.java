package Citizen;

public class Address {
}
